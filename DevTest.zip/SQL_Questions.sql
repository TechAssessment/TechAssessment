/*
Note that if you do not have SQL Server to try this on, you can go to the W3schools website and use the SQL try-it editor.
You'll need to be using a browser with WebSQL support - try it with Chrome!
https://www.w3schools.com/sql/trysql.asp?filename=trysql_op_in
You can build this schema in a DB through this site by pasting in one command at a time and executing it.
Note that this instance if SQL is cases sensitive.

Given this schema and data:
*/

create table department(department_id int NOT NULL, department_name varchar(100) NOT NULL, over_budget tinyint);
create table employee(employee_id int NOT NULL, last_name varchar(100) NOT NULL, first_name varchar(100) NOT NULL, department_id int, salary numeric(10,2));
create table task(task_id int NOT NULL, employee_id int, task_description varchar(256));
insert into department values(1,'Accounting',1),(2,'Sales',0),(3,'Research',0),(4,'Marketing',1);
insert into employee values(1,'Jackson','Bo',1,30000),(2,'Jordan','Michael',2,25000),(3,'Mattingly','Don',4,27000),(4,'Gretzky','Wayne',4,26500),(5,'Montana','Joe',3,33000),(6,'Tarkenton','Fran',2,24000),(7,'Comaneci','Nadia',1,31000),(8,'Solo','Hope',NULL,26000);
insert into task values(1,4,'Make Commercial'),(2,6,'Make Commercial'),(3,1,'Make Commercial'),(4,2,'Make Commercial'),(5,5,'Make Commercial'),(6,8,'Make Commercial'),(7,3,'Make Commercial'),(8,7,'Make Commercial'),(9,5,'Make Commercial'),(10,4,'Make Commercial');
select * from department;

-- Question #1:
--  Select all employee entires in the "Accounting" department.  The statement you write  should reference "accounting", not the account department id of 1.

-- Question #2:
--  Select the number of employees that make between $30,000.00 and $35,000.00.

-- Question #3:
--  Select all rows from Employee sorted alphabetically by last_name.

-- Question #4:
--  Select all task rows that are to be performed by an employee with the first name "Joe".

-- Question #5:
--  Select all employee first and last names, and the department names (may be NULL) that they work for.

-- Question #6:
--  Select the total salary of employees for each department (using one statement)

-- Question #7:
--  Select a list of tasks that have to be reassigned because they are currently assigned to employees making $30,000.00 or more in departments that are over budget (ie over_budget = 1).
