/*
    In Visual Studio Code, open a terminal and execute: dotnet new console
    This should setup a new .NET project with a Program.cs file.
    To run it, from the terminal, execute: dotnet run

    Now replace the content of the Program.cs file with the content of this file.
    Run it again by executing: dotnet run
    See below for questions.  Read the comments!
*/

using System;

namespace DevTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hello candidate!");

            Console.WriteLine(MathUtil.Average(2, 1));

            Console.WriteLine(StringUtil.CapitalizeSecond("this is a test."));

            Vehicle o = new Vehicle();
            o.brand = "Toyota";
            o.honk();
        }
    }

    // Question #1: What is wrong with this code?  Can you fix it?    
    public class MathUtil
    {
        public static double Average(int a, int b)
        {
            return a + b / 2;
        }
  
    }
    // Question #2: Can you create a new method (AverageExtended) that is extended to support more numbers (up to 50) in the average calculation as input?
    //  Call it from Main to show it working.

    // Question #3: Capitalize the second letter (if there is one) of every word in inputString
    //              Assume: Single space between every word
    public class StringUtil
    {
        public static string CapitalizeSecond(string inputString)
        {
            string retString = inputString;

            return retString;
        }
    }

    // Question #4: Add a truck class that writes "Beep, beep!" to the console when the honk method is called.  Truck otherwise functions like any other vehicle.
    //  Note that a truck is a type of Vehicle.
    //  Instantiate the new class in main and call the honk method.
    public class Vehicle
    {
        public string brand;  // Vehicle field
        public void honk()             // Vehicle method 
        {
            Console.WriteLine("Tuut, tuut!");
        }
        public void accelarate()             // Vehicle method 
        {
            Console.WriteLine("Going Faster!");
        }
    }


}

