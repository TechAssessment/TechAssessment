// If you have VSCode and node installed...
// Open a new terminal window (View -> Terminal or Terminal -> New Terminal)
// Type: node js_questions.js
// It should print "hello candidate!" (plus some other outputs) to the terminal.  If so, you are good to proceed!
// See below for questions.  Read the comments!
var msg = "hello candidate!";
console.log(msg);

// Question #1...
//  Debug this function.  It should be returning 42. Fix it by adding/removing only one character.
function problemOne() {
    var x = 99;
    x -= 50;
    x * 2;
    x = (x < 50 ? x += 75 : x -= 56);
    return x;
}

var A1 = problemOne()
console.log("Answer to question 1: " + A1);

// Question #2...
//  Debug this function.  It should be returning true. Fix it by adding only one character.
function problemTwo() {
    var x = "hello";
    var y = "world";
    var e_index = x.indexOf("e");
    var w_index = y.indexOf("w");
    if (w_index = 0) {
        return true;
    }
    else {
        return false;
    }
}

var A2 = problemTwo()
console.log("Answer to question 2: " + A2);


